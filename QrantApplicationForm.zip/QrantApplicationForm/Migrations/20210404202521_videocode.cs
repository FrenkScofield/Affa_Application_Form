﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace QrantApplicationForm.Migrations
{
    public partial class videocode : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "VideoCode",
                table: "ApplicationForms",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "VideoCode",
                table: "ApplicationForms");
        }
    }
}
